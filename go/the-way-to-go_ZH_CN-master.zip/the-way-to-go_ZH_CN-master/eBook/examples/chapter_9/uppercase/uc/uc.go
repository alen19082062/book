// uc.go
package uc

import "strings"

func UpperCase(str string) string {
	return strings.ToUpper(str)
}

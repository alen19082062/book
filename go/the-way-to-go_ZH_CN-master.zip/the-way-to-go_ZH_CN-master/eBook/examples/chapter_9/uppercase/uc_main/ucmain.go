// main.go
package main

import (
	"fmt"
	"uppercase/uc"
)

func main() {
	str1 := "USING package uc!"
	fmt.Println(uc.UpperCase(str1))
}

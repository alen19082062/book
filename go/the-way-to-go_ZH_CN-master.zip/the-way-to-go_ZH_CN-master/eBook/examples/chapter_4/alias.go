package main

import fm "fmt" // alias

func main() {
	fm.Println("hello, world")
}
